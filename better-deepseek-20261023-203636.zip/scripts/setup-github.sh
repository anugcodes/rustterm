#!/usr/bin/env bash
# One-time helper: create the GitHub repo and push the initial scaffold.
# Requires the GitHub CLI (`gh`) to be installed and authenticated.
#
# Usage: ./scripts/setup-github.sh <your-github-username>

set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "Usage: $0 <github-username>" >&2
  exit 1
fi

GH_USER="$1"
REPO_NAME="
